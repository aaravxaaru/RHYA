Instructions to install and run Rhya Assistant.
1. Install Python 3.11+
2. pip install -r requirements.txt
3. python rhya.py
